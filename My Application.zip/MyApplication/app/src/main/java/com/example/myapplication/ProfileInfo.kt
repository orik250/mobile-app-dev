package com.example.myapplication

class ProfileInfo(
    val image: Int,
    val name: String,
    val detail1: String,
    val detail2: String,
)